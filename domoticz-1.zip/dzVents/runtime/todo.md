pandoc -r markdown README.md -t mediawiki -o README.wiki
dzVenst.lua (testmode)
version update (c++, doc, dzVents.lua, utils.log, testUtils.log)
tests ok

webroot https://www.domoticz.com/forum/viewtopic.php?f=59&t=20970&p=162316#p162316
twilight stuff

setpoint stuff EvoHome
sethue, setcolbrightness

lastseen prop for (zwave) devices?

room as group?

subfolders

notify > afterxxx support

more settings in domoticz.settings

load global_data as the first module: http://www.domoticz.com/forum/viewtopic.php?f=59&t=23018&p=177534#p177534
